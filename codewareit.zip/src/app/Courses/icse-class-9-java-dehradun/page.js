import courseData from "../courseData";
import CourseLandingPage from "../CourseLandingPage";

const SLUG = "icse-class-9-java-dehradun";

export async function generateMetadata() {
  const course = courseData[SLUG];
  return {
    title: course.metaTitle,
    description: course.metaDescription,
    keywords: course.keywords,
    openGraph: {
      title: course.metaTitle,
      description: course.metaDescription,
      url: `https://www.codewareit.in/Courses/${SLUG}`,
      siteName: "Codeware IT Pvt Ltd",
      locale: "en_IN",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: course.metaTitle,
      description: course.metaDescription,
    },
    alternates: {
      canonical: `https://www.codewareit.in/Courses/${SLUG}`,
    },
  };
}

export default function Page() {
  const course = courseData[SLUG];
  return <CourseLandingPage course={course} />;
}
